import argparse
import numpy as np
import os
from os import listdir
import cv2
import time
import tensorflow.keras
from tensorflow.keras import layers, models, callbacks
from sklearn.utils import class_weight
from pathlib import Path



image_dimensions = (224, 224)
epochs = 10
model_name = 'posture_model.h5'
keyboard_spacebar = 32
global training_dir
training_dir = 'train'


def doliveview():
    mymodel = models.load_model(model_name)

    # Video capture stuff
    videocapture = cv2.VideoCapture(0)
    if not videocapture.isOpened():
        raise IOError('Cannot open webcam')

    while True:
        _, frame = videocapture.read()
        cv2.imwrite('thisframe.png', frame)
        im_color = cv2.imread('thisframe.png')
        im = cv2.cvtColor(im_color, cv2.COLOR_BGR2GRAY)

        im = cv2.resize(im, image_dimensions)
        im = im / 255  # Normalize the image
        im = im.reshape(1, image_dimensions[0], image_dimensions[1], 1)

        predictions = mymodel.predict(im)
        class_pred = np.argmax(predictions) 
        conf = predictions[0][class_pred]

        im_color = cv2.resize(im_color, (800, 480), interpolation = cv2.INTER_AREA)
        im_color = cv2.flip(im_color, flipCode=1) # flip horizontally

        if (class_pred==1):
            # Slumped
            im_color = cv2.putText(im_color, 'Bad posture!!', (550, 465),  cv2.FONT_HERSHEY_COMPLEX, 1,  (0, 0, 255), thickness = 1)
        else:
            im_color = cv2.putText(im_color, 'Good', (620, 465),  cv2.FONT_HERSHEY_COMPLEX, 1,  (0, 255, 0), thickness = 1)

        msg = '{}%'.format(round(int(conf*100)))
        im_color = cv2.putText(im_color, msg, (2, 25),  cv2.FONT_HERSHEY_COMPLEX, 1,  (0, 200, 255), thickness = 2)

        cv2.imshow('', im_color)
        cv2.moveWindow('', 20, 20);
        key = cv2.waitKey(20)

        if key == keyboard_spacebar:
            break

    videocapture.release()
    cv2.destroyAllWindows()


def do_training():
    train_images = []
    train_labels = []
    class_folders = listdir('train')
    class_label_indexer = 0
    for c in class_folders:
        print('Training with class {}'.format(c))
        for f in listdir('{}/{}'.format('train', c)):
            im = cv2.imread('{}/{}/{}'.format('train', c, f), 0)
            im = cv2.resize(im, image_dimensions)
            train_images.append(im)
            train_labels.append(class_label_indexer)
        class_label_indexer = class_label_indexer + 1

    train_images = np.array(train_images)
    train_labels = np.array(train_labels)
    

    indices = np.arange(train_labels.shape[0])
    
    np.random.shuffle(indices)
    images = train_images[indices]
    labels = train_labels[indices]
    train_images = np.array(train_images)
    train_images = train_images / 255  # Normalize image
    n = len(train_images)
    train_images = train_images.reshape(n, image_dimensions[0], image_dimensions[1], 1)

    
    class_weights = class_weight.compute_sample_weight('balanced', train_labels)
    class_weights = {i : class_weights[i] for i in range(15)}
    model = models.Sequential()
    model.add(layers.Conv2D(32, (3, 3), activation='relu', input_shape=(image_dimensions[0], image_dimensions[1], 1)))
    model.add(layers.MaxPooling2D((2, 2)))
    model.add(layers.Conv2D(64, (3, 3), activation='relu'))
    model.add(layers.MaxPooling2D((2, 2)))
    model.add(layers.Conv2D(64, (3, 3), activation='relu'))
    model.add(layers.Flatten())
    model.add(layers.Dense(64, activation='relu'))
    model.add(layers.Dense(len(class_folders), activation='softmax'))
    model.compile(optimizer='adam', loss='sparse_categorical_crossentropy',  metrics=['accuracy'])
    model.fit(train_images, train_labels, epochs=epochs, class_weight = class_weights)
    model.save(model_name)
    
def main():
    parser = argparse.ArgumentParser(description='Posture monitor')

    parser.add_argument('--train', help='train model with captured images', action='store_true')
    parser.add_argument('--live', help='live view applying model to each frame', action='store_true')
    parser.add_argument('--sound', help='in conjunction with live view will make a sound', action='store_true')
    args = parser.parse_args()

    if args.train:
        do_training()
    elif args.live:
        doliveview()
    else:
        parser.print_help()

if __name__ == '__main__':
    main()
