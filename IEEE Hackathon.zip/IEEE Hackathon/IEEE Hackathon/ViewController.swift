//
//  ViewController.swift
//  IEEE Hackathon
//
//  Created by Cai Duyi on 27/2/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var startBtn: UIButton!
    @IBOutlet weak var pauseBtn: UIButton!
    @IBOutlet weak var resetBtn: UIButton!
    @IBOutlet weak var timeTxt: UITextField!
    
    var timer = Timer()
    
    let datePicker = UIDatePicker()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        createDatePicker()
    }
    
    @IBAction func startBtn(_ sender: Any) {
        timer.invalidate()
        
        // create the timer
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ViewController.timerClass), userInfo: nil, repeats: true)
    }
    
    @IBAction func pauseBtn(_ sender: Any) {
        timer.invalidate()
    }
    
    @IBAction func resetBtn(_ sender: Any) {
        timer.invalidate()
        
        
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        formatter.dateStyle = .none
        formatter.dateFormat = "HH:mm:ss"
        
        let someDateTime = Date(timeIntervalSinceReferenceDate: -123494400.0)
        
        timeTxt.text = formatter.string(from: someDateTime)
        
        datePicker.date = someDateTime
        
        createDatePicker()
    }
    
    
    func createDatePicker(){
        // toolbar
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        timer.invalidate()
        
        // bar button
        let doneBtn = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressed))
        toolbar.setItems([doneBtn], animated: true)
        
        // assign toolbar
        timeTxt.inputAccessoryView = toolbar
        
        // assign date picker to the text field
        timeTxt.inputView = datePicker
        
        // datepicker to just show time
        datePicker.datePickerMode = .countDownTimer

    }
    
    @objc func donePressed(){
        timeTxt.textAlignment = .center
                
        // formatter
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        formatter.dateStyle = .none
        formatter.dateFormat = "HH:mm:ss"
        
        
        timeTxt.text = formatter.string(from: datePicker.date)
                
        self.view.endEditing(true)
    }
    
    @objc func timerClass(){
        
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        formatter.dateStyle = .none
        formatter.dateFormat = "HH:mm:ss"
        
        datePicker.date -= 1
        timeTxt.text = formatter.string(from: datePicker.date)
        
        if(timeTxt.text == "00:00"){
            timer.invalidate()
        }
    }
}

